#=========================================================================
#copy right 2018  tingwu.all rights reserved
#Date :  2016.03.02
#function: jpg FileReader
#Writer: Tingwu
#email: 18510665908@163.com
#CSVReader.py
#=========================================================================
#!/usr/bin/env python
# -*- coding: utf-8 -*-

import matplotlib.pyplot as plt
import tensorflow as tf
import os